#!/bin/bash
#python3.5 administratorCMD.py
python3.5 starter.py "$@"